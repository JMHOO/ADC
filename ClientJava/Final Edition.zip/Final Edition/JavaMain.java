/* TCSS558 Applied Distributed Computing 
 * 
 * Copyright (c) 2016 Yuyang Yu. */

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.Scanner;
import java.io.File;  
import java.io.FileNotFoundException;  
import java.io.PrintWriter;
import com.googlecode.jsonrpc4j.JsonRpcHttpClient;  
import com.googlecode.jsonrpc4j.ProxyUtil;  
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
  
public class JavaMain {
	private final static Logger logger = LoggerFactory.getLogger(JavaClient.class);
	private static OperateCSV csv = new OperateCSV();
	
	private static String serverIP ="73.140.72.152";
	private static String serverPortNumber = "15003";
	
	private static String inputFile = "src/kvp-operations.csv";
	private static final String outputFileTcp = "src/output_tcp.csv";
	private static final String outputFileUdp = "src/output_udp.csv";
	private static final String outputFileRPC = "src/output_rpc.csv";
	
    public static void main(String[] args) throws Throwable {  
    	String method = null;
    	// create a Scanner object
		Scanner input = new Scanner(System.in);
    	
		try {
    		if (args.length == 4) {
    			serverIP = args[0];
    			serverPortNumber = args[1];
    			method = args[2];
    			inputFile = args[3];
    		}
    		else if (args.length == 3) {
    			serverIP = args[0];
    			serverPortNumber= args[1];
    			method = args[2];
    		}
    		else if (args.length == 2) {
    			serverIP = args[0];
    			serverPortNumber= args[1];
    			// prompt the user to select protocol
    			System.out.println("Please enter TCP/UDP/RPC as communication protocol: ");
				method = input.nextLine();
    		}
    		else {
    			// prompt the user to enter the serverIP
				System.out.println("Please enter the server IP or name: ");
				serverIP = input.nextLine();
				// prompt the user to enter the port number
				System.out.println("Please enter the server port number: ");
				serverPortNumber = input.nextLine();
				// prompt the user to select protocol
				System.out.println("Please enter TCP/UDP/RPC as communication protocol: ");
				method = input.nextLine();
    		}

    		// TCP/UDP/RPC
    		if (method.toLowerCase().equals("tcp")) {
				JavaClient client_tcp = new JavaClient(serverIP, Integer.parseInt(serverPortNumber));
        		client_tcp.runOperations(inputFile, outputFileTcp, "TCP");
			} else if (method.toLowerCase().equals("udp")) {
				JavaClient client_udp = new JavaClient(serverIP, Integer.parseInt(serverPortNumber));
		        client_udp.runOperations(inputFile, outputFileUdp, "UDP");
			} else if (method.toLowerCase().equals("rpc")) {
				//manualRPC();
				autoRPC();
			} else {
				System.out.println("unsupport argument " + method);
			}
    	
    	}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		
		input.close();
		
		System.out.println("All done. :)");
    }
    
    // Manual - RPC
    private static void manualRPC() throws Throwable {
		// create a Scanner object
		Scanner input = new Scanner(System.in);
		// prompt the user to select command
		System.out.println("Please select your command: \n\t1 for PUT(key, value)\n\t2 for GET(key)\n\t3 for Delete(key)");
		int command = input.nextInt();
		input.nextLine();
		String key, value;
		Client c;
		// construct url
		String url = "http://".concat(serverIP).concat(":").concat(serverPortNumber);
		System.out.println("url: " + url);
		JsonRpcHttpClient client = new JsonRpcHttpClient(new URL(url));
		switch(command) {
			case 1:
				// prompt the user to enter key and value
				System.out.println("Please enter the key: ");
				key = input.nextLine();
				System.out.println("Please enter the value: ");
				value = input.nextLine();
				c = client.invoke("Put", new Object[] {key, value}, Client.class); 
		        System.out.println(c); 
				break;
			case 2:
				// prompt the user to enter key
				System.out.println("Please enter the key: ");
				key = input.nextLine();
				c = client.invoke("Get", new Object[] {key}, Client.class); 
		        System.out.println(c); 
				break;
			case 3:
				// prompt the user to enter key
				System.out.println("Please enter the key: ");
				key = input.nextLine();
				c = client.invoke("Delete", new Object[] {key}, Client.class); 
		        System.out.println(c); 
				break;
			default:
				System.out.println("Wrong command! Please follow the instruction!");
				System.exit(0);
				break;
		}
		// close the Scanner to avoid resource leak
		input.close();
	}
    
    // Auto - RPC
    private static void autoRPC() throws Throwable {
		Client c;
		String url = "http://".concat(serverIP).concat(":").concat(serverPortNumber);
		System.out.println("url: " + url);
		JsonRpcHttpClient client = new JsonRpcHttpClient(new URL(url));
		Long requestTime = null, responseTime = null;
		String operate;
		try {
			initialOutPut(outputFileRPC);
			List<String[]> operations = csv.readCVS(inputFile);
			System.out.println("csv:" + operations.size());
			for (int i = 1; i < operations.size(); i++) {
				operate = operations.get(i)[0];
				String key = operations.get(i)[1];
				String value = "";
				
				if (operate.equals("PUT")) {
					value = operations.get(i)[2];
					requestTime = System.currentTimeMillis();
					c = client.invoke("Put", new Object[] {key, value}, Client.class); 
					responseTime = System.currentTimeMillis();
				}
				else if (operate.equals("GET")) {
					requestTime = System.currentTimeMillis();
					c = client.invoke("Get", new Object[] {key}, Client.class);
					responseTime = System.currentTimeMillis();
				}
				else {
					requestTime = System.currentTimeMillis();
					c = client.invoke("Delete", new Object[] {key}, Client.class);
					responseTime = System.currentTimeMillis();
				}

				String duration = String.valueOf(responseTime - requestTime);
				String[] record = {operate, key, value,c.toString(), duration};
				csv.appendCSV(outputFileRPC, record);

			}
		} catch (Exception e) {
			logger.info("exception while open input csv file");
		}
    }
    
    public static void initialOutPut(String outputFile) {
		if (csv.isCSVExists(outputFile)) {
			csv.clearCVS(outputFile);
		} 
    	else {
			csv.createCSV(outputFile);
		}
		String[] head = {"operation", "key", "value", "response", "duration"};
		csv.appendCSV(outputFile, head);
	}
    
	public Logger getLogger() {
		return logger;
	}

	public OperateCSV getCsv() {
		return csv;
	}
}  